import React from 'react';
import { Component } from 'react'
import LoanApplication from './LoanApplication';
//import LoanRecords from './LoanRecords';
import Login from './Login';
import SignUp from './SignUp';
import DocumentSubmission from './DocumentSubmission'
import {withRouter} from 'react-router-dom'
import {Link,Route,Switch} from 'react-router-dom'
import ViewProfileCustomer from './ViewProfileCustomer';
import CustomerUpdateDetails from './CustomerUpdateDetails';
import ClerkFunctions from'./ClerkFunctions';
import ManagerFunctions from './ManagerFunctions';
import ViewExistingLoansById from  './ViewExistingLoansById';
import DisplayAllCustDetailsClerkMan from './DisplayAllCustDetailsClerkMan';
import {Layout} from './Layout';
//import {NavigationBar} from './NavigationBar';
import {Jumbotron} from './Jumbotron';
import { NavigationBar } from './NavigationBar';
import {Button,Alert,Card} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
//import {Carousel} from './Carousel';

class App extends React.Component{
  constructor(props){
    super(props);
  }
  render() {
    var obj={textAlign:'center'}
    return(
      
        <div>
          
          {/*<Card className="mb-3">
          <Card.Img src="https://newschant.com/wp-content/uploads/2020/03/Tips-to-get-another-home-loan-if-you-already-have-780x470.jpg"/>
          <Card.Body>
            <Card.Title>Home Loans</Card.Title>
            <Card.Text>Get Your Dream Home</Card.Text>
            <input type="button" value="Read More " className="btn btn-success"/>
           
          </Card.Body>
    </Card>*/}
          <div style={obj}>
            
          <NavigationBar />
            </div>

            <Jumbotron />
          <Layout>
          
        <Switch>
           <Route exact path="/" component={Login}></Route>
           <Route path="/customer" component={ViewProfileCustomer}></Route>
           <Route path="/clerk" component={ClerkFunctions}></Route>
           <Route path="/manager" component={ManagerFunctions}></Route>
           <Route path="/documents" component={DocumentSubmission}></Route>
           <Route path="/editDetails" component={CustomerUpdateDetails}></Route>
           <Route path="/loanApplication" component={LoanApplication}></Route>
           <Route path="/existingLoan" component={ViewExistingLoansById}></Route>
           <Route path="/displayCustomerDetails" component={DisplayAllCustDetailsClerkMan}></Route>
           {/*<Route path="/" component={}></Route>
           <Route path="/" component={}></Route>*/}
           </Switch>
           </Layout>
           <footer className="bg-dark text-white pt-5 pb-4 ">
             <div className="container text-center text-md-left">
               <div className="row text-center text-md-left">
                 <div className="col-md-3 col-lg-3 mx-auto mt-3">
                   <h5 className="text-uppercase mb-4 font-weight-bold text-warning">Ganesh Finance</h5>
                   <p>Ganesh Finance is one of the most pretigeous and elite service provider in the field of
                      Home,Car,Education and Instant loan since the last 12 years</p>
                   
                 </div>
                 <div className="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
                  <h5 className="text-uppercase mb-4 font-weight-bold text-warning">Giving service to:</h5>
                  <p>
                    <a href="http://fiitjee.com" className="text-white" >FIITJEE</a>
                  </p>
                  <p>
                    <a href="http://www.truevalue.com" className="text-white" >True Value</a>
                  </p>
                  <p>
                    <a href="http://www.dps.com" className="text-white" >Delhi Public School</a>
                  </p>
                 
             </div>
             <div className="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
               <h5 className="text-uppercase mb-4 font-weight-bold text-warning">Contact</h5>
               <p>
                 <i className="fas fa-home mr-3"></i>Ganesh Village, Global Tech Park, Bangalore
               </p>
               <p>
                 <i className="fas fa-envelop mr-3"></i>GaneshFinancial@GWG.com
               </p>
               <p>
                 <i className="fas fa-phone mr-3"></i>Toll Free: 1800-276543
               </p>
             </div>
             </div>
             
               </div>
           </footer>
        
           </div>
           
          
      
    )
  }
}
export default withRouter(App);
