import React from 'react'
import Axios from 'axios';
import LoanApplication from './LoanApplication'
import {Redirect} from 'react-router-dom'

import {Link,Route,Switch} from 'react-router-dom'
import {withRouter} from 'react-router-dom'
//import {Button} from 'react-bootstrap'
import {Button,Alert,Card} from 'react-bootstrap';
//import 'bootstrap/dist/css/bootstrap.min.css';

import 'bootstrap/dist/css/bootstrap.min.css';


class Login extends React.Component {
    constructor(props){
        super(props);
        this.state={email_id:"",password:"",role:"Customer",role_id:""}
       
    }

verify=()=>{
console.log(this.state);
console.log(this.state.role=="Customer")
if(this.state.role=="Customer"){
   
Axios.post("http://localhost:9092/checkDetails",{email_id:this.state.email_id,password:this.state.password})
.then(result=>{console.log(result);
    if(result.data){
    sessionStorage.setItem("cust_id",result.data)
    sessionStorage.setItem("role","Customer")
//alert("welcome")
this.props.history.push("/customer")
}
else(
    alert("try again")
)
})
.catch(error=>console.log(error))
}
else{
    Axios.post("http://localhost:9092/checkRoles",{roleId:this.state.email_id,password:this.state.password})
.then(result=>{if(result.data){
  if(this.state.role=="Manager"){
    sessionStorage.setItem("role","Manager")
    this.props.history.push("/manager")
    
  }else{
    sessionStorage.setItem("role","Clerk")
    this.props.history.push("/clerk")
  }
//alert("welcome role")
}
else(
    alert("try again")
)
})
.catch(error=>console.log(error))
}
}
changeValue=(event)=>{
    let inputName=event.target.name;
    let inputValue=event.target.value;
    this.setState({[inputName]:inputValue})
}

render() {
    var obj={textAlign:'center'}
    return (
           <div style={obj}>
            <h4>Customers</h4><p> Please choose your role as "Customer", enter your Username and Password to get the update of all the exciting offers on loans, to check status
             of your loan and to edit your details.</p>

          <h4>Managers</h4> <p>Please enter your credentials to mark approval of the pending loan applications.</p>
          <h4>Clerks</h4><p>Please enter your credentials to verify documentation of the loan applications.</p>

             <form >
             <label>Username</label>
                 <input type="text" name="email_id"  onChange={this.changeValue}/><br/>   
                 <label>Password</label>
                 <input type="password" name="password"  onChange={this.changeValue}/><br/> 
                 <select 
                 name="role"
                 className="btn btn-Success"
                 onChange={this.changeValue}
                 >
                     <option value="Customer">Customer</option>
                     <option value="Manager">Manager</option>
                     <option value="Clerk">Clerk</option>
                 </select>
                 <input type="button" value="submit"  className="btn btn-primary" onClick={this.verify}/>
                 <input type="reset" value="reset" className="btn btn-secondary"/>
                 
             </form>
            
           </div>
          




    )
}
}
export default Login;