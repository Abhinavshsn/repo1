import React from 'react';
import { Nav, Navbar, NavbarBrand } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import styled from 'styled-components';

const Styles = styled.div`
    .navbar{
        background-color: #222
    }

    .navbar-brand, .navbar-nav .nav-link {
        color: #bbb;
        
        &:hover {
            color: white;
        }
    }
`;

export const NavigationBar = () =>(
    <Styles>
        <Navbar expand="lg" className="fixed-top">
            <Navbar.Brand href="/">Ganesh Finance</Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav"/>
            <Navbar.Collapse id="basic-navbar-nav">
                <Nav className="ml-auto active">
                    
                    <Nav.Item><Nav.Link href="/">Home</Nav.Link></Nav.Item>                   
                    <Nav.Item><Nav.Link href="/About">About</Nav.Link></Nav.Item>
                    <Nav.Item><Nav.Link href="/Plans">View Plans</Nav.Link></Nav.Item>
                    <Nav.Item><Nav.Link href="/SignUp">SignUp</Nav.Link></Nav.Item>
                </Nav>
            </Navbar.Collapse>
        </Navbar>
    </Styles>
)