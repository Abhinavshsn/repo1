import React from 'react'
import Axios from 'axios';
import { NavigationBar } from './NavigationBar';

class DocumentSubmission extends React.Component{
    constructor(props){
        super(props);
       this.state={adhar_no:"",pancard:""}
        
    }
    changeValue=(event)=>{
        let inputName=event.target.name;
        let inputValue=event.target.value;
        this.setState({[inputName]:inputValue})
    }


setDetails=()=>{
    Axios.post("http://localhost:9092/storeDocs",{applicationNo:sessionStorage.getItem("application_no"),dateOfEnrollment:"",adharNo:this.state.adhar_no,pancard:this.state.pancard}).
    then(result=>{
       //alert("Documents submitted")
       this.props.history.push("/customer")
       // console.log(result)
    }).
    catch(error=>console.log(error))
}
render() {
   
    return(
         <div>
                         <label>Adhar Number</label>
                         <input type="text" name="adhar_no" onChange={this.changeValue}/><br/>
                         <label>Pancard</label>
                         <input type="text" name="pancard       " onChange={this.changeValue}/><br/>
                         <input type="button" value="submit" className="btn btn-primary" onClick={this.setDetails}/>
                         <input type="reset" value="reset" className="btn btn-secondary"/> 
            
         </div>






    )
         }

        }


export default DocumentSubmission;