import React from 'react'
import Axios from 'axios';

class SignUp extends React.Component {
    constructor(props){
        super(props);
        this.state={first_name:"",last_name:"",gender:"",contact:"",email_id:"",password:""}

       
    }
    setDetails=(event)=>{
        let k=event.target.name;
        let v=event.target.value;
        this.setState({[k]:v})
    }
    feed=()=>{
       // console.log(this.state)
       Axios.post("http://localhost:9092/storeCustomer",{cust_id:"",first_name:this.state.first_name,last_name:this.state.last_name,gender:this.state.gender,contact:this.state.contact,email_id:this.state.email_id,password:this.state.password}).
       then(result=>{
           if(result.data>0){
           sessionStorage.setItem("cust_id",result.data)
           sessionStorage.setItem("role","Customer")
           }
      alert("Registration success");
      this.props.history.push("/customer")
        
        // console.log(result)
     }).
     catch(error=>console.log(error))
    
    }
    render(){
        return(
            <div>
                <form>
                    <label>First Name</label>
                    <input type="text" name="first_name" onChange={this.setDetails}/><br/>
                         <label>Last Name</label>
                         <input type="text" name="last_name" onChange={this.setDetails}/><br/>
                         <label>Gender</label>
                         <input type="text" name="gender" onChange={this.setDetails}/><br/>
                         <label>Contact</label>
                         <input type="text" name="contact" onChange={this.setDetails}/><br/>
                         <label>Email id</label>
                         <input type="text" name="email_id" onChange={this.setDetails}/><br/>
                         <label>Password</label>
                         <input type="text" name="password" onChange={this.setDetails}/><br/>
                        
                         <input type="button" value="submit" onClick={this.feed}/>
                         
                </form>
            </div>




        )
    }
}
export default SignUp