import React from 'react'
import axios from 'axios';
class LoanRecords extends React.Component{
    constructor(props){
        super(props);
        
    }
}
render() {
    let LoanRec=this.state
    return(







    )
         }

}
export LoanRecords;