import React from 'react'
import axios from 'axios';

class ViewProfileCustomer extends React.Component{
    constructor(props){
        super(props);
        this.state={customer:{cust_id:0,first_name:"",last_name:"",gender:"",contact:0,email_id:"",password:""},cust_id:0,msg:""}
    }
    custById  = (event)=> {
        event.preventDefault();
        let cust_id= this.state.cust_id;
       axios.get("http://localhost:9092/getCustById/"+cust_id).  
       /* then(result=>this.setState({customers:result.data})).catch(error=>console.log(error)); */   //path param 
      then(result=>{
           if(result.data==""){
            console.log("Record not present")
            this.setState({msg:"Record is not present"})
           }else {
            this.setState({msg:""})
            console.log("REcord present")
            console.log(result.data)
            this.setState({msg:"Customer information"})
           this.setState({customer:result.data})
           
          
          

           }
       }).catch(error=>console.log(error));
    }
    changeValue=(event)=> {
        let name = event.target.name;
        let value = event.target.value;
        this.setState({[name]:value});
        
    }
    render() {
        

     return(
            <div>
            <h2>Customer Retrieve by Id From Spring Boot</h2>
            <form onSubmit={this.custById} >
                <label>Customer ID </label>
                <input type="text" name="cust_id" onChange={this.changeValue}/><br/>
                <input type="submit" value="My Details"/>
                <input type ="reset" value="reset"/>
            </form>
            {this.state.msg}<br/>
            {/*<label>Your customr id is:</label><br/>
           {this.state.customer.cust_id}<br/>
           <label>Your first name is:</label><br/>
            {this.state.customer.first_name}<br/>
            <label>Your last name is:</label><br/>
            {this.state.customer.last_name}<br/>
            <label>Your gender is:</label><br/>
            {this.state.customer.gender}<br/>
            <label>Your contact number is:</label><br/>
            {this.state.customer.contact}<br/>
            <label>Your Email Id is:</label><br/>
            {this.state.customer.email_id}<br/>*/}
             <hr/>
                <table border="1">
                    <thead>
                        <th>Cust Id</th>
                        
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Gender</th>
                        <th>Contact</th>
                        <th>Email id</th>
                       
                    </thead>
                    <tbody>
                       <td> {this.state.customer.cust_id}</td>
                       <td>{this.state.customer.first_name}</td>
                       <td>{this.state.customer.last_name}</td>
                       <td>{this.state.customer.gender}</td>
                       <td>{this.state.customer.contact}</td>
                       <td>{this.state.customer.email_id}</td>
                    </tbody>
                </table>
            <input type="submit" value="Edit my profile"/><br/>
            <input type="submit" value="Apply for new loan"/><br/>
            <input type="submit" value="View my existing loans"/><br/>
                       </div>
        )
    }
}

export default ViewProfileCustomer;