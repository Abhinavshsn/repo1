import React from 'react'
import axios from 'axios';

class DocumentsInsert extends React.Component{
    constructor(props){
        super(props);
        this.state={applicationNo:0.0,dateOfEnrollment:"",adharNo:0,pancard:"",msg:""}
    }
    storeDocs  = (event)=> {
        event.preventDefault();
     // console.log(this.state);
      let emp = this.state;
      axios.post("http://localhost:9092/storeDocs",emp).
      then(result=>this.setState({msg:result.data})).catch(error=>console.log(error));
    }
    changeValue=(event)=> {
        let name = event.target.name;
        let value = event.target.value;
        this.setState({[name]:value});
    }
    render() {

     return(
            <div>
                {this.state.msg}
            <h2>Insert a document </h2>
            <form onSubmit={this.storeDocs}>
                <label>Application No. </label>
                <input type="text" name="applicationNo" onChange={this.changeValue}/><br/>
                <label>Date of enrollment. </label>
                <input type="text" name="dateOfEnrollment" onChange={this.changeValue}/><br/>
                <label>Adhar Card number</label>
                <input type="text" name="adharNo" onChange={this.changeValue}/><br/>
                <label>Pancard number </label>
                <input type="text" name="pancard" onChange={this.changeValue}/><br/>
                <input type="submit" value="submit"/>
                <input type ="reset" value="rest"/>
            </form>

                       </div>
        )
    }
}



export default DocumentsInsert;