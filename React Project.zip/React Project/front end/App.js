import React from 'react';
import CustomerInsert from './CustomerInsert';
import CustomerUpdate from './CustomerUpdateEmail';
import CustomerDisplay from './DisplayAllCustDetailsClerkMan';
import CustomerDelete from './CustomerDelete';
import DocumentsInsert from './DocumentsInsert';
import DocumentsDisplay from './DocumentsDisplay';
import DocumentsDelete from './DocumentsDelete';
import CustomerValidation from './CustomerValidation'
import Login from './Login';
import DocumentsById from './DocumentsById';
import CustomerById from './ViewProfileCustomer';
import CustomerUpdateEmail from './CustomerUpdateEmail';
import CustomerUpdateContact from './CustomerUpdateContact';
import CustomerUpdatePassword from './CustomerUpdatePassword';
import ViewExistingLoansById from './ViewExistingLoansById';
import DisplayAllCustDetailsClerkMan from './DisplayAllCustDetailsClerkMan';
import DisplayAllCustDetById from './DisplayAllCustDetById';
import DisplayAllCustDetByLoanID from './DisplayAllCustDetByLoanID';
import DisplayAllCustDetByAppNo from './DisplayAllCustDetByAppNo';

class App extends React.Component{
  constructor(props){
    super(props);

  }
  render() {


    return(
      <div>
        <h1>This is My Web App</h1>
        
       {/*<CustomerInsert></CustomerInsert>
          <CustomerDisplay></CustomerDisplay>
        <CustomerById></CustomerById>
      CustomerUpdate></CustomerUpdate>
        <CustomerDelete></CustomerDelete>
        <DocumentsInsert></DocumentsInsert>
        <DocumentsDisplay></DocumentsDisplay> 
       <DocumentsById></DocumentsById>
        <DocumentsDelete></DocumentsDelete>
       
         
        <Login></Login>
        <CustomerValidation></CustomerValidation>
        <CustomerUpdateEmail></CustomerUpdateEmail>
        <CustomerUpdateContact></CustomerUpdateContact>
       <CustomerUpdatePassword></CustomerUpdatePassword>
       <ViewExistingLoansById></ViewExistingLoansById>
       <DisplayAllCustDetailsClerkMan></DisplayAllCustDetailsClerkMan>
       <DisplayAllCustDetById></DisplayAllCustDetById>
<DisplayAllCustDetByLoanID></DisplayAllCustDetByLoanID>*/}
<DisplayAllCustDetByAppNo></DisplayAllCustDetByAppNo>
      </div>
    )
  }
}
export default App;
