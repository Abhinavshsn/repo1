import React from 'react'
import axios from 'axios';

class DisplayAllCustDetByAppNo extends React.Component{
    constructor(props){
        super(props);
        this.state={customerAppNo:[],application_no:0,msg:""}
    }
    
    custByAppNo  = (event)=> {
        event.preventDefault();
        let application_no= this.state.application_no;
       axios.get("http://localhost:9092/allDetailsCustByAppNoClerk/"+application_no).  
       /* then(result=>this.setState({customers:result.data})).catch(error=>console.log(error)); */   //path param 
      then(result=>{
           if(result.data==""){
            console.log("Record not present")
            this.setState({msg:"Record is not present"})
           }else {
            this.setState({msg:""})
            console.log("REcord present")
            console.log(result.data)
            this.setState({msg:"Customer information"})
           this.setState({customerAppNo:result.data})
           
          
          

           }
       }).catch(error=>console.log(error));
    }
    
    changeValueAppNo=(event)=> {
        let name = event.target.name;
        let value = event.target.value;
        this.setState({[name]:value});}
   
        
        
    render() {
        
       
        let DocRecByAppNo = this.state.customerAppNo.map(e=><tr key={e.cust_id}><td>{e.cust_id}</td><td>{e.first_name}</td><td>{e.last_name}</td><td>{e.gender}</td><td>{e.contact}</td><td>{e.email_id}</td><td>{e.application_no}</td><td>{e.loan_duration}</td><td>{e.loan_amount}</td><td>{e.status}</td><td>{e.loan_type}</td><td>{e.interest}</td><td>{e.security1}</td><td>{e.adharNo}</td><td>{e.pancard}</td><td>{e.dateOfEnrollment}</td>></tr>)       
     return(
            <div>
            <h2>All Customer details of loans Retrieve by application number </h2>
            <form onSubmit={this. custByAppNo} >
                <label>Application number </label>
                <input type="text" name="application_no" onChange={this.changeValueAppNo}/><br/>
                <input type="submit" value="My Details"/>
                <input type ="reset" value="reset"/>
            </form>
            {this.state.msg}<br/>
            <hr/>
                <table border="1">
                    <thead>
                        <th>Customer Id</th>
                        
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Gender</th>
                        <th>Contact</th>
                        <th>Email id</th>
                        <th>Application no</th>
                        <th>loan durtn</th>
                        <th>loan amount</th>
                        <th>status</th>
                        <th>loan type</th>
                        <th>interest</th>
                        <th>security</th>
                        <th>adhar no</th>
                        <th>pancard</th>
                        <th>date of enroll</th>
                    </thead>
                    <tbody>
                       {DocRecByAppNo}
                    </tbody>
                    </table>

</div>
        )

        
    }
}

export default DisplayAllCustDetByAppNo;