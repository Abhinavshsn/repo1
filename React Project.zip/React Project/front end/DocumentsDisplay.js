import React from 'react'
import axios from 'axios';

class DocumentsDisplay extends React.Component{
    constructor(props){
        super(props);
        this.state={documents:[]}
    }
    loadDocuments  = ()=> {
       // axios.get("http://localhost:9090/allEmployees").
       // then(result=>console.log(result.data)).catch(error=>console.log(error));
       axios.get("http://localhost:9092/allDocuments").
       then(result=>this.setState({documents:result.data})).catch(error=>console.log(error));
    }
    render() {

 let DocRec = this.state.documents.map(e=><tr key={e.applicationNo}><td>{e.applicationNo}</td><td>{e.dateOfEnrollment}</td><td>{e.adharNo}</td><td>{e.pancard}</td></tr>)       

        return(
            <div>
                <h2>Documents Retrieve From Spring Boot</h2>
                <input type="button" value="LoadData" onClick={this.loadDocuments}/>
                <hr/>
                <table>
                    <thead>
                        <th>Application Id</th>
                        <th>Date of emrollment</th>
                        <th>Adhar card no.</th>
                        <th>Pancard no.</th>
                    </thead>
                    <tbody>
                        {DocRec}
                    </tbody>
                </table>
            </div>
        )
    }
}



export default DocumentsDisplay;