import React from 'react'
import axios from 'axios';

class CustomerValidation extends React.Component{
    constructor(props){
        super(props);
        this.state={email_id:"",password:"",msg:""}
    }
    storeCustomer  = (event)=> {
        event.preventDefault();
      //console.log(this.state);
      let emp = this.state;
      axios.post("http://localhost:9092/checkDetails",emp).
      then(result=>this.setState({msg:result.data})).catch(error=>console.log(error));
    }
    changeValue=(event)=> {
        let name = event.target.name;
        let value = event.target.value;
        this.setState({[name]:value});
    }
    render() {

     return(
            <div>
                {this.state.msg}
            <h2>Customer Validation in Spring boot</h2>
            <form onSubmit={this.storeCustomer}>
                
                <label>Customer Email  </label>
                <input type="text" name="email_id" onChange={this.changeValue}/><br/>
                <label>Customer password  </label>
                <input type="text" name="password" onChange={this.changeValue}/><br/>
                <input type="submit" value="submit"/>
                <input type ="reset" value="rest"/>
            </form>

                       </div>
        )
    }
}


export default CustomerValidation;