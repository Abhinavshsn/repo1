import React from 'react'
import axios from 'axios';

class CustomerUpdateContact extends React.Component{
    constructor(props){
        super(props);
        this.state={contact:0,cust_id:0,msg:""}
    }
    storeCustomer  = (event)=> {
        event.preventDefault();
      //console.log(this.state);
      let emp = this.state;
      axios.put("http://localhost:9092/updateCustomerContact",{contact:this.state.contact,cust_id:this.state.cust_id}).
      then(result=>this.setState({msg:result.data})).catch(error=>console.log(error));
    }
    changeValue=(event)=> {
        let name = event.target.name;
        let value = event.target.value;
        this.setState({[name]:value});
    }
    render() {

     return(
            <div>
                {this.state.msg}
            <h2>Customer Store in Spring boot</h2>
            <form onSubmit={this.storeCustomer}>
                <label>Customer Id </label>
                <input type="text" name="cust_id" onChange={this.changeValue}/><br/>
                
                <label>Customer Contact  </label>
                <input type="text" name="contact" onChange={this.changeValue}/><br/>
            
                <input type="submit" value="submit"/>
                <input type ="reset" value="rest"/>
            </form>

                       </div>
        )
    }
}


export default CustomerUpdateContact;