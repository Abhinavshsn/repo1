import React from 'react'
import axios from 'axios';

class ViewExistingLoansById extends React.Component{
    constructor(props){
        super(props);
        this.state={customer:[],cust_id:0,msg:""}
    }
    custById  = (event)=> {
        event.preventDefault();
        let cust_id= this.state.cust_id;
       axios.get("http://localhost:9092/ViewExistingLoansById/"+cust_id).  
       /* then(result=>this.setState({customers:result.data})).catch(error=>console.log(error)); */   //path param 
      then(result=>{
           if(result.data==""){
            console.log("Record not present")
            this.setState({msg:"Record is not present"})
           }else {
            this.setState({msg:""})
            console.log("REcord present")
            console.log(result.data)
            this.setState({msg:"Customer information"})
           this.setState({customer:result.data})
           
          
          

           }
       }).catch(error=>console.log(error));
    }
    changeValue=(event)=> {
        let name = event.target.name;
        let value = event.target.value;
        this.setState({[name]:value});
        
    }
    render() {
        
        let DocRec = this.state.customer.map(e=><tr key={e.application_no}><td>{e.application_no}</td><td>{e.loan_id}</td><td>{e.loan_duration}</td><td>{e.loan_amount}</td><td>{e.status}</td><td>{e.loan_type}</td><td>{e.interest}</td><td>{e.security1}</td><td>{e.dateOfEnrollment}</td><td>{e.adharNo}</td><td>{e.pancard}</td>></tr>)       

     return(
            <div>
            <h2>Customer Retrieve by Id From Spring Boot</h2>
            <form onSubmit={this.custById} >
                <label>Customer ID </label>
                <input type="text" name="cust_id" onChange={this.changeValue}/><br/>
                <input type="submit" value="My Details"/>
                <input type ="reset" value="reset"/>
            </form>
            {this.state.msg}<br/>
            {/*<label>Your customr id is:</label><br/>
           {this.state.customer.cust_id}<br/>
           <label>Your first name is:</label><br/>
            {this.state.customer.first_name}<br/>
            <label>Your last name is:</label><br/>
            {this.state.customer.last_name}<br/>
            <label>Your gender is:</label><br/>
            {this.state.customer.gender}<br/>
            <label>Your contact number is:</label><br/>
            {this.state.customer.contact}<br/>
            <label>Your Email Id is:</label><br/>
            {this.state.customer.email_id}<br/>*/}
             <hr/>
                <table border="1">
                    <thead>
                        <th>Application No</th>
                        
                        <th>Loan Id</th>
                        <th>Loan Duration</th>
                        <th>Loan amount</th>
                        <th>status</th>
                        <th>Loan type</th>
                        <th>Interest</th>
                        <th>Security</th>
                        <th>date of en</th>
                        <th>adhar</th>
                        <th>pancard</th>
                    </thead>
                    <tbody>
                       {DocRec}
                    </tbody>

                </table>
            <input type="submit" value="Exit"/><br/>
           
                       </div>
        )
    }
}

export default ViewExistingLoansById;