import React from 'react'
import axios from 'axios';

class CustomerDelete extends React.Component{
    constructor(props){
        super(props);
        this.state={customer:{cust_id:0,first_name:"",last_name:"",gender:"",contact:0,email_id:"",password:""},cust_id:0,msg:""}
    }
    custById  = (event)=> {
        event.preventDefault();
        let cust_id= this.state.cust_id;
       axios.delete("http://localhost:9092/deleteCustomer/"+cust_id).       //path param 
       then(result=>{
           if(result.data==""){
            console.log("Record not present")
            this.setState({msg:"Record is not present"})
           }else {
            this.setState({msg:""})
            console.log("REcord present")
            console.log(result.data)
            this.setState({msg:"Customer info delete"})
           this.setState({customer:result.data})
           }
       }).catch(error=>console.log(error));
    }
    changeValue=(event)=> {
        let name = event.target.name;
        let value = event.target.value;
        this.setState({[name]:value});
    }
    render() {

     return(
            <div>
            <h2>Customer Retrieve by Id From Spring Boot</h2>
            <form onSubmit={this.custById}>
                <label>Customer ID </label>
                <input type="text" name="cust_id" onChange={this.changeValue}/><br/>
                <input type="submit" value="submit"/>
                <input type ="reset" value="reset"/>
            </form>
            {this.state.msg}
           {this.state.customer.cust_id}<br/> {this.state.customer.first_name}<br/>{this.state.customer.last_name}<br/>{this.state.customer.gender}<br/>{this.state.customer.contact}<br/>{this.state.customer.email_id}<br/>{this.state.customer.password}
                       </div>
        )
    }
}



export default CustomerDelete;