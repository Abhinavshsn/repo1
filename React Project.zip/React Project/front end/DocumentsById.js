import React from 'react'
import axios from 'axios';

class DocumentsById extends React.Component{
    constructor(props){
        super(props);
        this.state={document:{id:0,dateOfEnrollment:"",adharNo:0,pancard:""},id:0,msg:""}
    }
    docsById  = (event)=> {
        event.preventDefault();
        let id = this.state.id;
       axios.get("http://localhost:9092/getDocsById/"+id).       //path param 
       then(result=>{
           if(result.data==""){
            console.log("Record not present")
            this.setState({msg:"Record is not present"})
           }else {
            this.setState({msg:""})
            console.log("REcord present")
            console.log(result.data)
            this.setState({msg:"Documents information"})
           this.setState({document:result.data})
           }
       }).catch(error=>console.log(error));
    }
    changeValue=(event)=> {
        let name = event.target.name;
        let value = event.target.value;
        this.setState({[name]:value});
    }
    render() {

     return(
            <div>
            <h2>Docuement Retrieve by From Spring Boot</h2>
            <form onSubmit={this.docsById}>
                <label>Application Number </label>
                <input type="text" name="id" onChange={this.changeValue}/><br/>
                <input type="submit" value="submit"/>
                <input type ="reset" value="reset"/>
            </form>
            {this.state.msg}
           {this.state.document.id}<br/> {this.state.document.dateOfEnrollment}<br/>{this.state.document.adharNo}<br/>{this.state.document.pancard}
                       </div>
        )
    }
}

export default DocumentsById;