import React from 'react'
import axios from 'axios';

class DisplayAllCustDetailsClerkMan extends React.Component{
    constructor(props){
        super(props);
        this.state={customers:[]}
    }
    loadCust  = ()=> {
       // axios.get("http://localhost:9090/allEmployees").
       // then(result=>console.log(result.data)).catch(error=>console.log(error));
       axios.get("http://localhost:9092/allDetailsCustomerClerkMan").
       then(result=>this.setState({customers:result.data})).catch(error=>console.log(error));
    }
    render() {

 let DocRec = this.state.customers.map(e=><tr key={e.application_no}><td>{e.application_no}</td><td>{e.cust_id}</td><td>{e.first_name}</td><td>{e.last_name}</td><td>{e.loan_type}</td><td>{e.interest}</td><td>{e.security1}</td><td>{e.status}</td><td>{e.loanDuration}</td><td>{e.loan_amount}</td><td>{e.adhar}</td><td>{e.pancard}</td><td>{e.date_of_enrollment}</td></tr>)       

        return(
            <div>
                <h2>Customer Retrieve From Spring Boot</h2>
                <input type="button" value="LoadData" onClick={this.loadCust}/>
                <hr/>
                <table border="1">
                    <thead>
                        <th>application no</th>
                        <th>cust id</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>loan type</th>
                        <th>interest</th>
                        <th>security</th>
                        <th>status</th>
                        <th>duration</th>
                        <th>amount</th>
                        <th>adhar</th>
                        <th>pancard</th>
                        <th>enrollment</th>
                    </thead>
                    <tbody>
                        {DocRec}
                    </tbody>
                </table>
            </div>
        )
    }
}





export default DisplayAllCustDetailsClerkMan;