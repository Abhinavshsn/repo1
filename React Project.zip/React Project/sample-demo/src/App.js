import React from 'react';
import Login from './Login';
import EmployeeDetails from './EmployeeDetails';

class App extends React.Component{
  constructor(props) {
    super(props);
  }

  render() {
    
    return(
      <div>
        <h1>This is my Web Page</h1>
       // <Login></Login>
      </div>
    )
  }
}

export default App;
