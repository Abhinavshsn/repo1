import React from 'react'
class Login extends React.Component {
    constructor(props){
        super(props);
        this.state={user:"",pass:""}
        this.verifyUser=this.verifyUser.bind(this);
    }
    verifyUser(event){
         event.preventDefault();
         if(this.state.user==="Ajay" && this.state.pass===123){
            console.log("Succesfully Login"); 
            this.setState({result:"Succesfully Login"}) 
         }else {
             this.setState({result:"Failure Try Once Again"})
         }
        
    }
    changeValue=(event)=>{
        let inputName=event.target.name;
        let inputValue=event.target.value;
        this.setState({[inputName]:inputValue})
    }
    render() {
        return(
            <div>
                {this.state.result}
                <h2>Login Page</h2>
                <form onSubmit={this.verifyUser}>
                    <label>UserName</label>
                    <input type="text" name="user"/><br/>
                    <label>Password</label>
                    <input type="password" name="pass"/><br/>
                    <input type="submit" value="submit"/>
                    <input type="reset" value="reset"/>
                </form>
            </div>
        )
    }
}
export default Login;