import React from 'react';
class Employee {
    constructor(id,name,salary) {
      this.id=id;
      this.name=name;
      this.salary=salary;
    }
  }
class EmployeeDetails extends React.Component {
    constructor(props){
    super(props);
    }

    render() {
        let employees=[];
        let emp1=new Employee(1,"ravi",10000);
        let emp2=new Employee(2,"ravi",11000);
        let emp3=new Employee(3,"ravi",12000);
        employees.push(emp1);
        employees.push(emp2);
        employees.push(emp3);

let EmpData=employees.map(e=><li>Id is {e.id},Name is {e.name},Salary is {e.salary}</li>)
        return(

            <div>
              <h2>All Employee Details</h2>
              <ul>
                  {EmpData}
              </ul>

            </div>
        )
    }
}
export default EmployeeDetails;