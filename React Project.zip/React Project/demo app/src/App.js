import React from 'react';

function Employee(props){
  return(
    <div>
      This is Employee component<br/>
      Your id is{props.id}
      Your age is{props.age}
      Your name is{props.name}
    </div>
  
  )
}

class App extends React.Component{
  constructor(props){
    super(props);
    this.state={id:100,name:""};
    this.display=this.display.bind(this);
  }
  display()
  {
    console.log("Function called");
    this.setState({id:101,name:"Raj"});
  
  }
render(){

//this.display();
  return(
    <div>
      {this.display}
   <h1>Wlecome to React JS Class style</h1> 
   <Employee id="100" age="21" name={this.state.name}></Employee>
    Id is {this.state.id} and Name is {this.state.name}
   <br/>
   <input type="button" value="Click Here" onClick={this.display}/>
   <input type="button" value="Arrow"
    onClick={()=>this.setState({id:102,name:"rakesh"})}/>
    </div>)
 
}
}

export default App;



/*import logo from './logo.svg';
import './App.css';
function Header(){
  return(
    <div>
      This is header
    </div>
  );
}
let Footer=()=><div>This is footer</div>
function App() {
  return (
   
   <div>
      <Header></Header>
     <h1>Welcome to react js</h1>
     <Footer></Footer>
   </div>
  
  );
}

export default App;*/
