import React from 'react'
import axios from 'axios';

class ManagerFunctions extends React.Component{
    constructor(props){
        super(props);
        this.state={cust:[],ByStat:[],msg:"",status:"",}
    }
    storeCustomer  = (event)=> {
        event.preventDefault();
      //console.log(this.state);
     
      axios.get("http://localhost:9092/updateStatus1",{msg:""}).
      then(result=>{
        console.log(result);
        if(result.data){
       alert("Approved")
        }
        else{
            alert("try again")
        }
       // console.log(result)
    }).
    catch(error=>console.log(error))
}
    storeCustomer1  = (event)=> {
        event.preventDefault();
      //console.log(this.state);
     
      
      axios.get("http://localhost:9092/updateStatus",{msg:""}).
      then(result=>{
        console.log(result);
        if(result.data){
       alert("UnApproved Successfully")
        }
        else{
            alert("try again")
        }
       // console.log(result)
    }).
    catch(error=>console.log(error))
     
    }
    storeCustomer2  = (event)=> {
        event.preventDefault();
      //console.log(this.state);
     
     
      axios.get("http://localhost:9092/updateStatus2",{msg:""}).
      then(result=>{
        console.log(result);
        if(result.data){
       alert("Pended Successfully")
        }
        else{
            alert("try again")
        }
       // console.log(result)
    }).
    catch(error=>console.log(error))
     
    }
    storeCustomer3 = (event)=> {
        event.preventDefault();
      //console.log(this.state);
     
     
      axios.get("http://localhost:9092/updateStatus3",{msg:""}).
      then(result=>{
        console.log(result);
        if(result.data){
       alert("Pended successfully")
        }
        else{
            alert("try again")
        }
       // console.log(result)
    }).
    catch(error=>console.log(error))
    }
    custByStatus  = (event)=> {
      event.preventDefault();
      let status= this.state.status;
     axios.get("http://localhost:9092/getEmailByStat/"+status).  
     /* then(result=>this.setState({customers:result.data})).catch(error=>console.log(error)); */   //path param 
    then(result=>{
         if(result.data==""){
         /* console.log("Record not present")
          this.setState({msg:"Record is not present"})*/
          alert("The status entered is wrong")
         }else {
          this.setState({msg:""})
         /* console.log("REcord present")
          console.log(result.data)
          this.setState({msg:"Customer information"})*/
          alert("The emails according to entered status are")
         this.setState({cust:result.data})
         
        
        

         }
     }).catch(error=>console.log(error));
  }
  loadNumberOfApp  = ()=> {
    // axios.get("http://localhost:9090/allEmployees").
    // then(result=>console.log(result.data)).catch(error=>console.log(error));
    axios.get("http://localhost:9092/allAppByStat").
    then(result=>{console.log(result.data);this.setState({ByStat:result.data})}).catch(error=>console.log(error));
 }
    changeValue=(event)=> {
        let name = event.target.name;
        let value = event.target.value;
        this.setState({[name]:value});
    }
    changeValue1=(event)=> {
      let name = event.target.name;
      let value = event.target.value;
      this.setState({[name]:value});
      
  }
LoginPage=()=>{
    this.props.history.push("/")
}
DisplayDetails=()=>{
    this.props.history.push("/displayCustomerDetails")
}
    render() {
      let DocRec = this.state.cust.map(e=><tr key={e.first_name}><td>{e.first_name}</td><td>{e.last_name}</td><td>{e.email_id}</td></tr>)     
      let DocRec1 = this.state.ByStat.map(e=><tr key={e.application_no}><td>{e.application_no}</td><td>{e.status}</td></tr>)         

     return(
            <div>
               
            <h2>Manager Functions</h2>
            <form >
                <label>Approve records with all documents submitted</label>
                <input type="submit" value="Approve Records" onClick={this.storeCustomer}/><br/>
                <label>Unpprove records with all documents submitted</label>
                <input type="submit" value="Unapprove Records" onClick={this.storeCustomer1}/><br/>
                <label>Pend records where Adhar number is submitted and pancard not submitted </label>
                <input type="submit" value="Pend Records" onClick={this.storeCustomer2}/><br/>
                <label>Pend records where adhar number is submitted and pancard is not submitted</label>
                <input type="submit" value="Pend Records" onClick={this.storeCustomer3}/><br/>
            </form>
            <hr/>
            <div>
            <h2>Get Email Id of the customer by status</h2>
            <ol><li>Approved</li>
            <li>Unapproved</li>
            <li>Pending</li></ol>
            <form onSubmit={this.custByStatus} >
                <label>Enter the status </label>
                <input type="text" name="status" onChange={this.changeValue1}/><br/>
                <input type="submit" value="Get Email"/>
                <input type ="reset" value="reset"/>
            </form>
            
                <table border="1">
                    <thead>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email Id</th>
                        
                    </thead>
                    <tbody>
                       {DocRec}
                    </tbody>

                </table>
                </div>
                <hr/>
                <h2>Number Of Applications per status</h2>
                <input type="button" value="LoadData" onClick={this.loadNumberOfApp}/>
               
                <table border="1">
                    <thead>
                        <th>Number Of Applications</th>
                        <th>Status</th>
                        
                    </thead>
                    <tbody>
                        {DocRec1}
                    </tbody>
                </table><br/>
                <input type="button" value="Exit" onClick={this.LoginPage}/>
                <input type="button" value="Next" onClick={this.DisplayDetails}/>

            
                       </div>
        )
    }
}


export default ManagerFunctions;