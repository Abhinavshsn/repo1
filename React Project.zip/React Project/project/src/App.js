import React from 'react';
import LoanApplication from './LoanApplication';
//import LoanRecords from './LoanRecords';
import Login from './Login';
import SignUp from './SignUp';
import DocumentSubmission from './DocumentSubmission'
import {withRouter} from 'react-router-dom'
import {Link,Route,Switch} from 'react-router-dom'
import ViewProfileCustomer from './ViewProfileCustomer';
import CustomerUpdateDetails from './CustomerUpdateDetails';
import ClerkFunctions from'./ClerkFunctions';
import ManagerFunctions from './ManagerFunctions';
import ViewExistingLoansById from  './ViewExistingLoansById';
import DisplayAllCustDetailsClerkMan from './DisplayAllCustDetailsClerkMan';
class App extends React.Component{
  constructor(props){
    super(props);
  }
  render() {
    return(
        <div>
        <h1>Welcome to my application</h1>
   
    <Switch>
           <Route exact path="/" component={Login}></Route>
           <Route path="/customer" component={ViewProfileCustomer}></Route>
           <Route path="/clerk" component={ClerkFunctions}></Route>
           <Route path="/manager" component={ManagerFunctions}></Route>
           <Route path="/documents" component={DocumentSubmission}></Route>
           <Route path="/editDetails" component={CustomerUpdateDetails}></Route>
           <Route path="/loanApplication" component={LoanApplication}></Route>
           <Route path="/existingLoan" component={ViewExistingLoansById}></Route>
           <Route path="/displayCustomerDetails" component={DisplayAllCustDetailsClerkMan}></Route>
           {/*<Route path="/" component={}></Route>
           <Route path="/" component={}></Route>*/}
           </Switch>

    
        </div>



      
    )
  }
}
export default withRouter(App);
