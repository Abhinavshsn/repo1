import React from 'react'
import Axios from 'axios';
class LoanApplication extends React.Component{
    constructor(props){
        super(props);
       this.state={application_no:"",laon_id:"",loan_amount:"",loan_duration:""}
        
    }
    changeValue=(event)=>{
        let inputName=event.target.name;
        let inputValue=event.target.value;
        this.setState({[inputName]:inputValue})
    }
    


getDetails=()=>{
    Axios.post("http://localhost:9092/storeApp",{cust_id:sessionStorage.getItem("cust_id"),application_no:"",loan_id:this.state.loan_id,loan_amount:this.state.loan_amount,loan_duration:this.state.loan_duration,status:"pending"}).
    then(result=>{
        console.log(result);
        if(result.data){
            sessionStorage.setItem("application_no",result.data)
 // alert("Applied for laon")
 this.props.history.push("/documents")
        }
        else{
            alert("try again")
        }
       // console.log(result)
    }).
    catch(error=>console.log(error))
}
render() {
   
    return(
         <div>
                         <label>Loan Id</label>
                         <input type="text" name="loan_id" onChange={this.changeValue}/><br/>
                         <label>Loan Amount</label>
                         <input type="text" name="loan_amount" onChange={this.changeValue}/><br/>
                         <label>Loan Duration</label>
                         <input type="text" name="loan_duration" onChange={this.changeValue}/><br/>
                         <input type="button" value="submit" onClick={this.getDetails}/>
                         <input type="reset" value="reset"/>   
         </div>






    )
         }

        }


export default LoanApplication;