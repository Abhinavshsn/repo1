import React from 'react'
import axios from 'axios';

class CustomerUpdateDetails extends React.Component{
    constructor(props){
        super(props);
        this.state={contact:0,cust_id:sessionStorage.getItem("cust_id"),email_id:"",password:"",msg:"",msg1:"",msg2:""}
    }
    storeCustomer  = (event)=> {
        event.preventDefault();
      //console.log(this.state);
      let emp = this.state;
      axios.put("http://localhost:9092/updateCustomerContact",{contact:this.state.contact,cust_id:this.state.cust_id}).
      then(result=>{if(result.data){
      
    alert("Updated successfully")
    }
    else(
        alert("Didnt updated")
    )
    })
    .catch(error=>console.log(error))
    }
    changeValue=(event)=> {
        let name = event.target.name;
        let value = event.target.value;
        this.setState({[name]:value});
    }
    storeCustomer1 = (event)=> {
        event.preventDefault();
      //console.log(this.state);
      let emp = this.state;
      axios.put("http://localhost:9092/updateCustomerEmail",{email_id:this.state.email_id,cust_id:this.state.cust_id}).
      then(result=>{if(result.data){
      
        alert("Updated successfully")
        }
        else(
            alert("Didnt updated")
        )
        })
        .catch(error=>console.log(error))
    }
    changeValue1=(event)=> {
        let name = event.target.name;
        let value = event.target.value;
        this.setState({[name]:value});
    }
    storeCustomer2  = (event)=> {
        event.preventDefault();
      //console.log(this.state);
      let emp = this.state;
      axios.put("http://localhost:9092/updateCustomerPassword",{password:this.state.password,cust_id:this.state.cust_id}).
      then(result=>{if(result.data){
      
        alert("Updated successfully")
        }
        else(
            alert("Didnt updated")
        )
        })
        .catch(error=>console.log(error))
    }
    changeValue2=(event)=> {
        let name = event.target.name;
        let value = event.target.value;
        this.setState({[name]:value});
    }


    ViewProfile=()=>{
        this.props.history.push("/customer")
    }
   
    render() {

     return(
            <div>
                {this.state.msg}
            <h2>Update Your Contact</h2>
            <form onSubmit={this.storeCustomer}>
               
                
                <label>Customer Contact  </label>
                <input type="text" name="contact" onChange={this.changeValue}/><br/>
            
                <input type="submit" value="submit"/>
                <input type ="reset" value="rest"/>
            </form>
            
                {this.state.msg1}
            <h2>Update Your Email Id</h2>
            <form onSubmit={this.storeCustomer1}>
              
                
                <label>Customer Email  </label>
                <input type="text" name="email_id" onChange={this.changeValue1}/><br/>
            
                <input type="submit" value="submit"/>
                <input type ="reset" value="rest"/>
            </form>
            {this.state.msg2}
            <h2>Update Your Password</h2>
            <form onSubmit={this.storeCustomer2}>
              
                
                <label>Customer Password  </label>
                <input type="text" name="password" onChange={this.changeValue2}/><br/>
            
                <input type="submit" value="submit"/>
                <input type ="reset" value="rest"/>

                <input type="button" value="Back" onClick={this.ViewProfile}/><br/>
            
            </form>


                       </div>

                       
        )
    }
}


export default CustomerUpdateDetails;