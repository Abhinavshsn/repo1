import React from 'react'
import axios from 'axios';

class ClerkFunctions extends React.Component{
    constructor(props){
        super(props);
        this.state={LoanRecords:[],LoanRecById:[],loan_id:0,loan_type:"",interest:"",security1:"",msg:"",msg1:""}
    }
    loadRec = ()=> {
       // axios.get("http://localhost:9090/allEmployees").
       // then(result=>console.log(result.data)).catch(error=>console.log(error));
       axios.get("http://localhost:9092/allRecord").
       then(result=>this.setState({LoanRecords:result.data})).catch(error=>console.log(error));
    }

    storeLoadRec  = (event)=> {
        event.preventDefault();
     // console.log(this.state);
      let emp = this.state;
      axios.post("http://localhost:9092/storeLoanRec",emp).
      then(result=>{
        console.log(result);
        if(result.data){
       alert("Stored Successfully")
        }
        else{
            alert("try again")
        }
       // console.log(result)
    }).
    catch(error=>console.log(error))
    }
    changeValue1=(event)=> {
        let name = event.target.name;
        let value = event.target.value;
        this.setState({[name]:value});
    }

    LoanRecDelById  = (event)=> {
        event.preventDefault();
        let loan_id = this.state.loan_id;
       axios.delete("http://localhost:9092/deleteloanrec/"+loan_id).       //path param 
       then(result=>{
           if(result.data==""){
            /*console.log("Record not present")
            this.setState({msg:"Record is not present"})*/
            alert("Loan Record does not exist")
           }else {
            this.setState({msg1:""})
           /* console.log("document deleted")
            console.log(result.data)
            this.setState({msg1:"loan record  deleted"})*/
            alert("Loan record deleted")
           
           }
       }).catch(error=>console.log(error));
    }
    changeValue2=(event)=> {
        let name = event.target.name;
        let value = event.target.value;
        this.setState({[name]:value});
    }
    LoginPage1=()=>{
        this.props.history.push("/")
    }
    DisplayDetails=()=>{
        this.props.history.push("/displayCustomerDetails")
    }
    render() {

 let loadRec1 = this.state.LoanRecords.map(e=><tr key={e.loan_id}><td>{e.loan_id}</td><td>{e.loan_type}</td><td>{e.interest}</td><td>{e.security1}</td></tr>)       

        return(
            <div><div>
                <h2>All Loan Records</h2>
                <input type="button" value="LoadData" onClick={this.loadRec}/>
                
                <table>
                    <thead>
                        <th>Loan Id</th>
                        <th>Loan Type</th>
                        <th>Interest</th>
                        <th>Security</th>
                    </thead>
                    <tbody>
                        {loadRec1}
                    </tbody>
                </table></div>
<hr/>
               
<div>

            <h2>Insert a loan record </h2>
            <form onSubmit={this.storeLoadRec}>
                <label>Loan Id </label>
                <input type="text" name="loan_id" onChange={this.changeValue1}/><br/>
                <label>Loan Type </label>
                <input type="text" name="loan_type" onChange={this.changeValue1}/><br/>
                <label>Interest</label>
                <input type="text" name="interest" onChange={this.changeValue1}/><br/>
                <label>Security</label>
                <input type="text" name="security1" onChange={this.changeValue1}/><br/>
                <input type="submit" value="submit"/>
                <input type ="reset" value="rest"/>
               
            </form>
</div>
<div>
<h2>Loan Record Delete </h2>
            <form onSubmit={this. LoanRecDelById}>
                <label>Loan Id to be deleted </label>
                <input type="text" name="loan_id" onChange={this.changeValue2}/><br/>
                <input type="submit" value="submit"/>
                <input type ="reset" value="reset"/>
                
            </form>
           
          
</div>
<input type="button" value="Exit" onClick={this.LoginPage1}/>
<input type="button" value="Next" onClick={this.DisplayDetails}/>
            </div>
        )
    }
}



export default ClerkFunctions;