import React from 'react'
import axios from 'axios';

class DisplayAllCustDetailsClerkMan extends React.Component{
    constructor(props){
        super(props);
        this.state={customers:[],customerAppNo:[],customer:[],cust_id:0,customerLoanId:[],loan_id:0,application_no:0,msg:""}
    }
    loadCust  = ()=> {
       // axios.get("http://localhost:9090/allEmployees").
       // then(result=>console.log(result.data)).catch(error=>console.log(error));
       axios.get("http://localhost:9092/allDetailsCustomerClerkMan").
       then(result=>this.setState({customers:result.data})).catch(error=>console.log(error));
    }
    custByAppNo  = (event)=> {
        event.preventDefault();
        let application_no= this.state.application_no;
       axios.get("http://localhost:9092/allDetailsCustByAppNoClerk/"+application_no).  
       /* then(result=>this.setState({customers:result.data})).catch(error=>console.log(error)); */   //path param 
      then(result=>{
           if(result.data==""){
            /*console.log("Record not present")
            this.setState({msg:"Record is not present"})*/
            alert("The record does not exist")
           }else {
            this.setState({msg:""})
           /* console.log("REcord present")
            console.log(result.data)
            this.setState({msg:"Customer information"})*/
            alert("Records retrieved according to application number successfully")
           this.setState({customerAppNo:result.data})
           
          
          

           }
       }).catch(error=>console.log(error));
    }
    custById  = (event)=> {
        event.preventDefault();
        let cust_id= this.state.cust_id;
       axios.get("http://localhost:9092/allDetailsCustByCustClerk/"+cust_id).  
       /* then(result=>this.setState({customers:result.data})).catch(error=>console.log(error)); */   //path param 
      then(result=>{
           if(result.data==""){
           /* console.log("Record not present")
            this.setState({msg:"Record is not present"})*/
            alert("Record does not exist")
           }else {
            this.setState({msg:""})
            /*console.log("REcord present")
            console.log(result.data)
            this.setState({msg:"Customer information"})*/
            alert("Recored retrieved according to customer id successfully")
           this.setState({customer:result.data})
           
          
          

           }
       }).catch(error=>console.log(error));
    }
    custByLoanId  = (event)=> {
        event.preventDefault();
        let loan_id= this.state.loan_id;
       axios.get("http://localhost:9092/allDetailsCustByLoanClerk/"+loan_id).  
       /* then(result=>this.setState({customers:result.data})).catch(error=>console.log(error)); */   //path param 
      then(result=>{
           if(result.data==""){
           /* console.log("Record not present")
            this.setState({msg:"Record is not present"})*/
            alert("Record does not exist")
           }else {
            this.setState({msg:""})
            /*console.log("REcord present")
            console.log(result.data)
            this.setState({msg:"Customer information"})*/
            alert("Record retrieved by loan id successsfully")
           this.setState({customerLoanId:result.data})
           
          
          

           }
       }).catch(error=>console.log(error));
    }
    
    changeValueLoan=(event)=> {
        let name = event.target.name;
        let value = event.target.value;
        this.setState({[name]:value});}
   
        
    changeValue=(event)=> {
        let name = event.target.name;
        let value = event.target.value;
        this.setState({[name]:value});}
    
    changeValueAppNo=(event)=> {
        let name = event.target.name;
        let value = event.target.value;
        this.setState({[name]:value});}

        LoginPage=()=>{

        }
   
    render() {

 let DocRec = this.state.customers.map(e=><tr key={e.application_no}><td>{e.application_no}</td><td>{e.cust_id}</td><td>{e.first_name}</td><td>{e.last_name}</td><td>{e.loan_type}</td><td>{e.interest}</td><td>{e.security1}</td><td>{e.status}</td><td>{e.loanDuration}</td><td>{e.loan_amount}</td><td>{e.adhar}</td><td>{e.pancard}</td><td>{e.date_of_enrollment}</td></tr>)       
 let DocRecByAppNo = this.state.customerAppNo.map(e=><tr key={e.cust_id}><td>{e.cust_id}</td><td>{e.first_name}</td><td>{e.last_name}</td><td>{e.gender}</td><td>{e.contact}</td><td>{e.email_id}</td><td>{e.application_no}</td><td>{e.loan_duration}</td><td>{e.loan_amount}</td><td>{e.status}</td><td>{e.loan_type}</td><td>{e.interest}</td><td>{e.security1}</td><td>{e.adharNo}</td><td>{e.pancard}</td><td>{e.dateOfEnrollment}</td>></tr>)
 let DocRecByCustId = this.state.customer.map(e=><tr key={e.cust_id}><td>{e.cust_id}</td><td>{e.first_name}</td><td>{e.last_name}</td><td>{e.gender}</td><td>{e.contact}</td><td>{e.email_id}</td><td>{e.application_no}</td><td>{e.loan_duration}</td><td>{e.loan_amount}</td><td>{e.status}</td><td>{e.loan_type}</td><td>{e.interest}</td><td>{e.security1}</td><td>{e.adharNo}</td><td>{e.pancard}</td><td>{e.dateOfEnrollment}</td>></tr>)
 let DocRecByLoanId = this.state.customerLoanId.map(e=><tr key={e.cust_id}><td>{e.cust_id}</td><td>{e.first_name}</td><td>{e.last_name}</td><td>{e.gender}</td><td>{e.contact}</td><td>{e.email_id}</td><td>{e.application_no}</td><td>{e.loan_duration}</td><td>{e.loan_amount}</td><td>{e.status}</td><td>{e.loan_type}</td><td>{e.interest}</td><td>{e.security1}</td><td>{e.adharNo}</td><td>{e.pancard}</td><td>{e.dateOfEnrollment}</td>></tr>)       
 return( <div>
            <div>
                <h2>Customer Retrieve From Spring Boot</h2>
                <input type="button" value="LoadData" onClick={this.loadCust}/>
                <hr/>
                <table border="1">
                    <thead>
                        <th>application no</th>
                        <th>cust id</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>loan type</th>
                        <th>interest</th>
                        <th>security</th>
                        <th>status</th>
                        <th>duration</th>
                        <th>amount</th>
                        <th>adhar</th>
                        <th>pancard</th>
                        <th>enrollment</th>
                    </thead>
                    <tbody>
                        {DocRec}
                    </tbody>
                </table>
                </div>
                <hr/>
                <div>
            <h2>All Customer details of loans Retrieve by application number </h2>
            <form onSubmit={this. custByAppNo} >
                <label>Application number </label>
                <input type="text" name="application_no" onChange={this.changeValueAppNo}/><br/>
                <input type="submit" value="My Details"/>
                <input type ="reset" value="reset"/>
            </form>
            <br/>
            <hr/>
                <table border="1">
                    <thead>
                        <th>Customer Id</th>
                        
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Gender</th>
                        <th>Contact</th>
                        <th>Email id</th>
                        <th>Application no</th>
                        <th>loan durtn</th>
                        <th>loan amount</th>
                        <th>status</th>
                        <th>loan type</th>
                        <th>interest</th>
                        <th>security</th>
                        <th>adhar no</th>
                        <th>pancard</th>
                        <th>date of enroll</th>
                    </thead>
                    <tbody>
                       {DocRecByAppNo}
                    </tbody>
                    </table>
                    </div>
                    <hr/>
                    <div>
            
                    <h2>All Customer details of loans Retrieve by loan Id </h2>
            <form onSubmit={this. custByLoanId} >
                <label>Loan ID </label>
                <input type="text" name="loan_id" onChange={this.changeValueLoan}/><br/>
                <input type="submit" value="My Details"/>
                <input type ="reset" value="reset"/>
            </form>
           <br/>
            <hr/>
                <table border="1">
                    <thead>
                        <th>Customer Id</th>
                        
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Gender</th>
                        <th>Contact</th>
                        <th>Email id</th>
                        <th>Application no</th>
                        <th>loan durtn</th>
                        <th>loan amount</th>
                        <th>status</th>
                        <th>loan type</th>
                        <th>interest</th>
                        <th>security</th>
                        <th>adhar no</th>
                        <th>pancard</th>
                        <th>date of enroll</th>
                    </thead>
                    <tbody>
                       {DocRecByLoanId}
                    </tbody>
                    </table></div>
                    <hr/>
                    <div>
                    <h2>All Customer details of loans Retrieve by customer Id </h2>
            <form onSubmit={this.custById} >
                <label>Customer ID </label>
                <input type="text" name="cust_id" onChange={this.changeValue}/><br/>
                <input type="submit" value="My Details"/>
                <input type ="reset" value="reset"/>
            </form>
           <br/>
            <hr/>
                <table border="1">
                    <thead>
                        <th>Customer Id</th>
                        
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Gender</th>
                        <th>Contact</th>
                        <th>Email id</th>
                        <th>Application no</th>
                        <th>loan durtn</th>
                        <th>loan amount</th>
                        <th>status</th>
                        <th>loan type</th>
                        <th>interest</th>
                        <th>security</th>
                        <th>adhar no</th>
                        <th>pancard</th>
                        <th>date of enroll</th>
                    </thead>
                    <tbody>
                       {DocRecByCustId}
                    </tbody>
                    </table><br/>


</div>
<input type="button" value="Exit" onClick={this.LoginPage2}/>
</div>
        
        )
    }
}





export default DisplayAllCustDetailsClerkMan;