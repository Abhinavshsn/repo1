package finance.bean;

public class LoanApplication {
	
	
	private int application_no;
	private int cust_id;
	private int loan_id;
	private int loan_duration;
	private long loan_amount;
	private String status;
	
	
	public int getApplication_no() {
		return application_no;
	}


	public void setApplication_no(int application_no) {
		this.application_no = application_no;
	}


	public int getCust_id() {
		return cust_id;
	}


	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}


	public int getLoan_id() {
		return loan_id;
	}


	public void setLoan_id(int loan_id) {
		this.loan_id = loan_id;
	}


	public int getLoan_duration() {
		return loan_duration;
	}


	public void setLoan_duration(int loan_duration) {
		this.loan_duration = loan_duration;
	}


	public long getLoan_amount() {
		return loan_amount;
	}


	public void setLoan_amount(long loan_amount) {
		this.loan_amount = loan_amount;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}

	
	
}
