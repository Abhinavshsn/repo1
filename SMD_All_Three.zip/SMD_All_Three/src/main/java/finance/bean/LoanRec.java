package finance.bean;

public class LoanRec {
	
	private long loan_id;
	private String loan_type;
	private String interest;
	private String security1;
	public long getLoan_id() {
		return loan_id;
	}
	public void setLoan_id(long loan_id) {
		this.loan_id = loan_id;
	}
	public String getLoan_type() {
		return loan_type;
	}
	public void setLoan_type(String loan_type) {
		this.loan_type = loan_type;
	}
	public String getInterest() {
		return interest;
	}
	public void setInterest(String interest) {
		this.interest = interest;
	}
	public String getSecurity1() {
		return security1;
	}
	public void setSecurity1(String security1) {
		this.security1 = security1;
	}

}
