package finance.bean;

public class Document {
	
	private float applicationNo;
	private String dateOfEnrollment;
	private long adharNo;
	
	@Override
	public String toString() {
		return "Documents [applicationNo=" + applicationNo + ", dateOfEnrollment=" + dateOfEnrollment + ", adharNo="
				+ adharNo + ", pancard=" + pancard + "]";
	}
	private String pancard;
	public float getApplicationNo() {
		return applicationNo;
	}
	public void setApplicationNo(float applicationNo) {
		this.applicationNo = applicationNo;
	}
	public String getDateOfEnrollment() {
		return dateOfEnrollment;
	}
	public void setDateOfEnrollment(String dateOfEnrollment) {
		this.dateOfEnrollment = dateOfEnrollment;
	}
	public long getAdharNo() {
		return adharNo;
	}
	public void setAdharNo(long adharNo) {
		this.adharNo = adharNo;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	
	

}
