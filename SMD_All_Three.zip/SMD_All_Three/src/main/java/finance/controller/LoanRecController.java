package finance.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import finance.bean.Customer;
import finance.bean.LoanRec;
import finance.service.CustomerService;
import finance.service.LoanRecService;

@RestController
public class LoanRecController {

	@Autowired
	LoanRecService loanrecService;
	
	
	@GetMapping(value = "allRecord",produces = MediaType.APPLICATION_JSON_VALUE)
	public List<LoanRec> getAllLoanRec() {
		System.out.println("In Controller");
		return loanrecService.getAllLoanRec();
	}
	
	@GetMapping(value = "getLoanRecById/{loan_id}",produces = MediaType.APPLICATION_JSON_VALUE)
	public LoanRec getLoanRecById(@PathVariable("loan_id") long loan_id) {
		return loanrecService.getLoanRecById(loan_id);
	}
	
	@PostMapping(value = "storeLoanRec")
	public String storeLoanRec(@RequestBody LoanRec lr) {
		return loanrecService.storeLoanRecord(lr);
	}
	
	@PutMapping(value = "updateLoanRec")
	public String updateLoanRec(@RequestBody LoanRec lr) {
		return loanrecService.updateLoanRecord(lr);
	}
	
	@DeleteMapping(value = "deleteloanrec/{loan_id}")
	public String storeEmployee(@PathVariable("loan_id") long loan_id) {
		System.out.println(loan_id);
		return loanrecService.deleteLoanRecById(loan_id);
	}
}
