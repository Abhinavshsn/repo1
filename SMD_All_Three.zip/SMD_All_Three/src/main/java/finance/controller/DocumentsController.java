package finance.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import finance.bean.Document;
import finance.service.DocumentsService;

import finance.bean.Document;

@RestController
public class DocumentsController {
@Autowired
DocumentsService documentsService;
@GetMapping(value = "allDocuments",produces = MediaType.APPLICATION_JSON_VALUE)
public List<Document> getAllDocuments(){
	System.out.println("In controller");
	return documentsService.getAllDocuments();
}
@GetMapping(value="getDocsById/{id}",produces=MediaType.APPLICATION_JSON_VALUE)
public Document getDocsById(@PathVariable("id")int id) {
	System.out.println("NO");
	return documentsService.getDocumentsByApplicationNo(id);
}
@PostMapping(value="storeDocs",consumes=MediaType.APPLICATION_JSON_VALUE)
public String storeDocs(@RequestBody Document doc) {
	System.out.println("in controller"+doc);
	return documentsService.storeDocuments(doc);
}
@DeleteMapping(value="deleteDocs/{id}")
public String storeDocs(@PathVariable("id")int id) {
	return documentsService.deleteDocumentsDetails(id);
}
}
