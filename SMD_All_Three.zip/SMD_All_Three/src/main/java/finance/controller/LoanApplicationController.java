package finance.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import finance.bean.LoanApplication;
import finance.service.LoanApplicationService;

@RestController
public class LoanApplicationController {

	@Autowired
	LoanApplicationService ls;
	
	@GetMapping(value="Applications_list", produces=MediaType.APPLICATION_JSON_VALUE)
	public List<LoanApplication> getAllApp(){
		System.out.println("In Controller");
		return ls.getAllApplication();
	}
	
	@GetMapping(value = "{appno.}", produces = MediaType.APPLICATION_JSON_VALUE)
	public LoanApplication getAppById(@PathVariable("appno.") int id) {
		return ls.getApplicationById(id);
	}
	
	@PostMapping(value = "storeApp")
	public String storeApp(@RequestBody LoanApplication la) {
		return ls.storeApplicationDetails(la);
	}
	
	/*@PutMapping(value = "updateApp")
	public String updateApp(@RequestBody LoanApplication la) {
		return las.updateApplicationDetails(la);
	}*/
	
	@DeleteMapping(value = "deleteApp/{appno.}")
	public String deleteApp(@PathVariable("appno.") int id) {
		return ls.deleteApplicationById(id);
	}

}
