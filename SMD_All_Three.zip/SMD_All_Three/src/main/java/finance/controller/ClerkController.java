package finance.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import finance.bean.Clerk;
import finance.bean.Customer;
import finance.bean.LoanApplication;
import finance.service.ClerkService;

@RestController
public class ClerkController {
	@Autowired
	ClerkService cs;
	
	
	
	//@Autowired
	//Customer c;
	
	/*@GetMapping(value = "path/{uname}/{Password}")
	public String getPathParamInfo(@PathVariable("uname") String uname, @PathVariable("Password") int pswd) {
		if(uname=="Sam45" && pswd==14568) {
			return "Welcome "+uname;
		}else {
			return "User "+uname+" you are not Authorised to enter ";
		}
	}*/
	@GetMapping(value ="loanDetails",produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Clerk> getLoanDetails() {
		return cs.getAllLoanDetails();
	}
	
	@GetMapping(value="application", produces=MediaType.APPLICATION_JSON_VALUE)
	public List<LoanApplication> getAllApp(){
		System.out.println("In Controller");
		return cs.getAllApp();
	}
	
	@PostMapping(value = "storeApps")
	public String storeApplication(@RequestBody LoanApplication la) {
		return cs.storeApp(la);
	}
	
	@GetMapping(value = "customersDetails",produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Customer> getAllCustomers() {
		System.out.println("In Controller");
		return cs.getAllCust();
	}
	
	@DeleteMapping(value = "deleteApplication/{appno.}")
	public String deleteApp(@PathVariable("appno.") int id) {
		return cs.deleteApplicationById(id);
	}
	
	@PutMapping(value = "updateCustomers")
	public String updateCustomer(@RequestBody Customer cust) {
		return cs.updateCustomerDetails(cust);
	}
	
	@DeleteMapping(value = "deleteCustomers/{cust_id}")
	public String storeEmployee(@PathVariable("cust_id") long cust_id) {
		System.out.println(cust_id);
		return cs.deleteCustomerById(cust_id);
	}

	
	

}
