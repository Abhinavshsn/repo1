package finance.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import finance.bean.Customer;
import finance.bean.Document;
import finance.bean.LoanApplication;
import finance.bean.LoanRec;
import finance.bean.Manager;
import finance.service.DocumentsService;
import finance.service.LoanApplicationService;
import finance.service.LoanRecService;
import finance.service.CustomerService;
import finance.service.ManagerService;


@RestController
public class ManagerController {
	

	@Autowired
	CustomerService customerService;

	@Autowired
	DocumentsService documentsService;
	

	@Autowired
	LoanApplicationService loanapplicationService;
	

	@Autowired
	LoanRecService loanrecService;
	
	@Autowired
	ManagerService managerService;
	
	
	@GetMapping(value = "updateStatus")
	public String updateRecords() {
		return managerService.getAllDetails();
	}
	
	

	@GetMapping(value = "getEmailByStat/{status}",produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Customer> getManagerById(@PathVariable("status") String status) {
		return managerService.getManagerById(status);
	}
	@GetMapping(value = "allAppByStat",produces = MediaType.APPLICATION_JSON_VALUE)
	public List<LoanApplication> getAllEmployees() {
		System.out.println("In Controller");
		return managerService.getAllRecByStatus();
	}
	
	

}
