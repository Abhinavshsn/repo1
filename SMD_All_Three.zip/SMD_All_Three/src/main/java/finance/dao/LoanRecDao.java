package finance.dao;

import org.springframework.stereotype.Repository;
import org.springframework.beans.factory.annotation.Autowired;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;


import finance.bean.Customer;
import finance.bean.LoanRec;

@Repository			//DAO layer specific annotation 
public class LoanRecDao {
	@Autowired
	DataSource dataSource;					//DataSource features of JDBC driverName,url,userName,password
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	public List<LoanRec> getAllLoanRec() {
	List<LoanRec> listOfRec = new ArrayList<LoanRec>();
		try {
			con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
			pstmt = con.prepareStatement("select * from loan_rec");
			rs = pstmt.executeQuery();
			while(rs.next()) {
				LoanRec lr = new LoanRec();
				lr.setLoan_id(rs.getLong(1));
				lr.setLoan_type(rs.getString(2));
				lr.setInterest(rs.getString(3));
				lr.setSecurity1(rs.getString(4));
			
				
				
				listOfRec.add(lr);
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return listOfRec;
	}
	
	public LoanRec getLoanRecById(long loan_id) {
		try {
			con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
			pstmt = con.prepareStatement("select * from loan_rec where loan_id=?");
			pstmt.setLong(1, loan_id);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				LoanRec lr = new LoanRec();
				lr.setLoan_id(rs.getLong(1));
				lr.setLoan_type(rs.getString(2));
				lr.setInterest(rs.getString(3));
				lr.setSecurity1(rs.getString(4));
				return lr;
			}
		}catch (Exception e) {
			
		}
		return null;
	}
	
	public int storeLoanRecord(LoanRec lr) {
		try {
			con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
			pstmt = con.prepareStatement("insert into loan_rec values(?,?,?,?)");
			pstmt.setLong(1, lr.getLoan_id());
			pstmt.setString(2,lr.getLoan_type() );
			pstmt.setString(3, lr.getInterest());
			pstmt.setString(4, lr.getSecurity1());
		
			return pstmt.executeUpdate();			//if success
		}catch (Exception e) {
			return 0;											//failure 
		}
	}
	
	public int updateLoanRecord(LoanRec lr) {
		try {
			con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
			pstmt = con.prepareStatement("update loan_rec set loan_type =? where loan_id=?");
			pstmt.setLong(2, lr.getLoan_id());
			pstmt.setString(1, lr.getLoan_type());
			return pstmt.executeUpdate();			//if success
		}catch (Exception e) {
			return 0;											//failure 
		}
	}
	
	
	
	public int deleteLoanRecById(long loan_id) {
		try {
			con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
			pstmt = con.prepareStatement("delete from loan_rec where loan_id=?");
			pstmt.setLong(1, loan_id);
			return pstmt.executeUpdate();			//if success
		}catch (Exception e) {
			return 0;											//failure 
		}
	}
}