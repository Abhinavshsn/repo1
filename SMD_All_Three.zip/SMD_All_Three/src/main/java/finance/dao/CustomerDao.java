package finance.dao;

import org.springframework.stereotype.Repository;
import org.springframework.beans.factory.annotation.Autowired;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;


import finance.bean.Customer;

@Repository			//DAO layer specific annotation 
public class CustomerDao {
	@Autowired
	DataSource dataSource;					//DataSource features of JDBC driverName,url,userName,password
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	public List<Customer> getAllCustomerDetails() {
		List<Customer> listOfRec = new ArrayList<Customer>();
			try {
				con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
				pstmt = con.prepareStatement("select * from customer");
				rs = pstmt.executeQuery();
				while(rs.next()) {
					Customer cus = new Customer();
					cus.setCust_id(rs.getLong(1));
					cus.setFirst_name(rs.getString(2));
					cus.setLast_name(rs.getString(3));
					cus.setGender(rs.getString(4));
					cus.setContact(rs.getLong(5));
					cus.setEmail_id(rs.getString(6));
					cus.setPassword(rs.getString(7));
					
					listOfRec.add(cus);
				}
			} catch (Exception e) {
				System.out.println(e.toString());
			}
			return listOfRec;
		}
		
		public Customer getCustomerById(long cust_id) {
			try {
				con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
				pstmt = con.prepareStatement("select * from customer where cust_id=?");
				pstmt.setLong(1, cust_id);
				rs = pstmt.executeQuery();
				if(rs.next()) {
					Customer cust = new Customer();
					cust.setCust_id(rs.getLong(1));
					cust.setFirst_name(rs.getString(2));
					cust.setLast_name(rs.getString(3));
					cust.setGender(rs.getString(4));
					cust.setContact(rs.getLong(5));
					cust.setEmail_id(rs.getString(6));
					cust.setPassword(rs.getString(7));
					return cust;
				}
			}catch (Exception e) {
				
			}
			return null;
		}
		
		public int storeCustomerRecord(Customer cust) {
			try {
				con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
				pstmt = con.prepareStatement("insert into customer values(?,?,?,?,?,?,?)");
				pstmt.setLong(1, cust.getCust_id());
				pstmt.setString(2,cust.getFirst_name() );
				pstmt.setString(3, cust.getLast_name());
				pstmt.setString(4, cust.getGender());
				pstmt.setLong(5, cust.getContact());
				pstmt.setString(6,cust.getEmail_id() );
				pstmt.setString(7,cust.getPassword() );
				return pstmt.executeUpdate();			//if success
			}catch (Exception e) {
				return 0;											//failure 
			}
		}
		
		public int updateCustomerContact(Customer cust) {
			try {
				con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
				pstmt = con.prepareStatement("update customer set contact =? where cust_id=?");
				pstmt.setLong(2, cust.getCust_id());
				pstmt.setLong(1, cust.getContact());
				return pstmt.executeUpdate();			//if success
			}catch (Exception e) {
				return 0;											//failure 
			}
		}
		
		public int updateCustomerPassword(Customer cust) {
			try {
				con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
				pstmt = con.prepareStatement("update customer set password =? where cust_id=?");
				pstmt.setLong(2, cust.getCust_id());
				pstmt.setString(1, cust.getPassword());
				return pstmt.executeUpdate();			//if success
			}catch (Exception e) {
				return 0;											//failure 
			}
		}
		
		public int updateCustomerMailId(Customer cust) {
			try {
				con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
				pstmt = con.prepareStatement("update customer set email_id =? where cust_id=?");
				pstmt.setLong(2, cust.getCust_id());
				pstmt.setString(1, cust.getEmail_id());
				return pstmt.executeUpdate();			//if success
			}catch (Exception e) {
				return 0;											//failure 
			}
		}
		
		public String checkDetails(Customer cust) {
			try {
				con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
				pstmt = con.prepareStatement("select password from customer where email_id=?");
				pstmt.setString(1, cust.getEmail_id());
				rs= pstmt.executeQuery();			//if success
				if(rs.next())
				{
					return rs.getString(1);
					
				}
				else {
					return null;
				}
				
			}catch (Exception e) {
				return null;											//failure 
			}
		}
		
		
		
		public int deleteCustomerById(long cust_id) {
			try {
				con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
				pstmt = con.prepareStatement("delete from customer where cust_id=?");
				pstmt.setLong(1, cust_id);
				return pstmt.executeUpdate();			//if success
			}catch (Exception e) {
				return 0;											//failure 
			}
		}
}