package finance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import finance.bean.Customer;
import finance.dao.CustomerDao;
import finance.service.CustomerService;
import finance.bean.Document;
import finance.dao.DocumentsDao;
import finance.service.DocumentsService;
import finance.bean.LoanApplication;
import finance.dao.LoanApplicationDao;
import finance.service.LoanApplicationService;
import finance.bean.LoanRec;
import finance.dao.LoanRecDao;
import finance.service.LoanRecService;
import finance.bean.Manager;
import finance.dao.ManagerDao;
import finance.service.ManagerService;

@Repository
public class ManagerDao {
	
	/*update loan_application set status='pending'  where application_no in(select application_no from loan_application where application_no in (select application_no from documents where adhar_no is null or pancard like('null')))
			update loan_application set status='unapproved'  where application_no in(select application_no from loan_application where application_no in (select application_no from documents where adhar_no is null and pancard like('null')))
			update loan_application set status='approved'  where application_no in(select application_no from loan_application where application_no in (select application_no from documents where adhar_no is not null or pancard  not like 'null'))
			*/
	@Autowired
	DataSource dataSource;					//DataSource features of JDBC driverName,url,userName,password
    Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	
	public  int getAllDetails() {
		
			try {
				con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
				pstmt = con.prepareStatement("update loan_application set status='pending'  where application_no in(select application_no from loan_application where application_no in (select application_no from documents where adhar_no is null or pancard like('null')))");
				pstmt = con.prepareStatement("update loan_application set status='unapproved'  where application_no in(select application_no from loan_application where application_no in (select application_no from documents where adhar_no is null and pancard like('null')))");
				pstmt = con.prepareStatement("update loan_application set status='approved'  where application_no in(select application_no from loan_application where application_no in (select application_no from documents where adhar_no is not null or pancard  not like 'null'))");
				rs = pstmt.executeQuery();
				
					
					
				return pstmt.executeUpdate();
				}
			catch (Exception e) {
				System.out.println(e.toString());
			}
			return 0;
		}
	
	
	public List<Customer> getManagerById(String status) {
		List<Customer> listOfRec = new ArrayList<Customer>();
		try {
			con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
			pstmt = con.prepareStatement("select email_id from customer where cust_id in (select cust_id from loan_application where status like ?)");
			pstmt.setString(1, status);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				Customer cus = new Customer();
				
				cus.setEmail_id(rs.getString(1));
				
				
				listOfRec.add(cus);
			}
		
		}catch (Exception e) {
			System.out.println(e);
			
		}
		return listOfRec;
	}
	
	public List<LoanApplication> getAllCustomerDetails() {
		List<LoanApplication> listOfRec = new ArrayList<LoanApplication>();
			try {
				con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
				pstmt = con.prepareStatement("select count(application_no),status from loan_application group by status");
				rs = pstmt.executeQuery();
				while(rs.next()) {
					LoanApplication ls = new LoanApplication();
					ls.setApplication_no(rs.getInt(1));
					ls.setStatus(rs.getString(2));
					
					
					
					listOfRec.add(ls);
				}
			} catch (Exception e) {
				System.out.println(e.toString());
			}
			return listOfRec;
		}
	
			
			

}
