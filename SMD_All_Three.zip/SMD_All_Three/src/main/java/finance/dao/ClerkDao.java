package finance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import finance.bean.Clerk;
import finance.bean.Customer;
import finance.bean.LoanApplication;

@Repository
public class ClerkDao {
	@Autowired
	DataSource dataSource;
	Statement stmt;
	PreparedStatement pstmt;
	Connection con;
	ResultSet rs;
	
	public List<Clerk> getAllCustomerDetails() {
		List<Clerk> listOfRec = new ArrayList<Clerk>();
		
			try {
				con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
				stmt = con.createStatement();
				rs = stmt.executeQuery("SELECT LA.APPLICATION_NO,C1.CUST_ID,C1.FIRST_NAME,C1.LAST_NAME,LR.LOAN_TYPE,LA.LOAN_DURATION,LA.LOAN_AMOUNT,D1.ADHAR_NO,D1.PANCARD FROM CUSTOMER C1,LOAN_APPLICATION LA,lOAN_REC LR,DOCUMENTS D1 \r\n" + 
						"WHERE C1.CUST_ID=LA.CUST_ID AND LA.APPLICATION_NO=D1.APPLICATION_NO AND LA.LOAN_ID=LR.LOAN_ID");
				while(rs.next()) {
					Clerk ck=new Clerk();
					ck.setApplication_no(rs.getInt(1));
					ck.setCust_id(rs.getInt(2));
					ck.setFirst_name(rs.getString(3));
					ck.setLast_name(rs.getString(4));
					ck.setLoan_type(rs.getString(5));
					ck.setLoan_amount(rs.getLong(6));
					ck.setAdhar(rs.getLong(7));
					ck.setPancard(rs.getString(8));
					
					listOfRec.add(ck);
					
	            	   	
				}
				
			} catch (Exception e) {
				System.out.println(e.toString());
			}
			return listOfRec;
		}
	
	public List<LoanApplication> getAllApplications(){
		List<LoanApplication> listOfRec = new ArrayList<LoanApplication>();
		try {
			con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
			pstmt = con.prepareStatement("select * from loan_application");
			rs = pstmt.executeQuery();
			while(rs.next()) {
				LoanApplication la = new LoanApplication();
				la.setApplication_no(rs.getInt(1));
				la.setCust_id(rs.getInt(2));
				la.setLoan_id(rs.getInt(3));
				la.setLoan_duration(rs.getInt(4));
				la.setLoan_amount(rs.getLong(5));
				la.setStatus(rs.getString(6));
				listOfRec.add(la);
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return listOfRec;
	}
	
	public String storeLapRecord(LoanApplication la) {
		try {
			con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
			pstmt = con.prepareStatement("insert into loan_application values(?,?,?,?,?,?)");
			pstmt.setInt(1, la.getApplication_no());
			pstmt.setInt(2, la.getCust_id());
			pstmt.setInt(3, la.getLoan_id());
			pstmt.setInt(4, la.getLoan_duration());
			pstmt.setLong(5, la.getLoan_amount());
			pstmt.setString(6, la.getStatus());
			pstmt.executeUpdate();		
			return "Loaded in the loan_application records";//if success
		}catch (Exception e) {
			return e.toString();											//failure 
		}
	}
	
	public List<Customer> getAllCustomer() {
		List<Customer> listOfRec = new ArrayList<Customer>();
			try {
				con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
				pstmt = con.prepareStatement("select * from customer");
				rs = pstmt.executeQuery();
				while(rs.next()) {
					Customer cus = new Customer();
					cus.setCust_id(rs.getLong(1));
					cus.setFirst_name(rs.getString(2));
					cus.setLast_name(rs.getString(3));
					cus.setGender(rs.getString(4));
					cus.setContact(rs.getLong(5));
					cus.setEmail_id(rs.getString(6));
					
					
					listOfRec.add(cus);
				}
			} catch (Exception e) {
				System.out.println(e.toString());
			}
			return listOfRec;
		}
	
	public String deleteLapById(int AppNo) {
		try {
			con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
			pstmt = con.prepareStatement("delete from loan_application where application_no= ?");
			pstmt.setInt(1, AppNo);
			pstmt.executeUpdate();	
			return "Deleted";
		}catch (Exception e) {
			return e.toString();											//failure 
		}
	}
	
	public int updateCustomerDetails(Customer cust) {
		try {
			con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
			pstmt = con.prepareStatement("update customer set first_name =? where cust_id=?");
			pstmt.setLong(2, cust.getCust_id());
			pstmt.setString(1, cust.getFirst_name());
			return pstmt.executeUpdate();			//if success
		}catch (Exception e) {
			return 0;											//failure 
		}
	}
	
	public int deleteCustomerById(long cust_id) {
		try {
			con = dataSource.getConnection();				// getting the connection with help of DataSource using application.properties file 
			pstmt = con.prepareStatement("delete from customer where cust_id=?");
			pstmt.setLong(1, cust_id);
			return pstmt.executeUpdate();			//if success
		}catch (Exception e) {
			return 0;											//failure 
		}
	}

				
	

}
