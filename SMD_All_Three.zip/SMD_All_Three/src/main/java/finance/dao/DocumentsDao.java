package finance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import finance.bean.Document;

@Repository
public class DocumentsDao {
	@Autowired
	DataSource dataSource;					
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	public List<Document> getDocumentsDetails() {
		List<Document> listOfRec = new ArrayList<Document>();
			try {
				con = dataSource.getConnection();				
				pstmt = con.prepareStatement("select * from documents");
				rs = pstmt.executeQuery();
				while(rs.next()) {
					Document doc = new Document();
					doc.setApplicationNo(rs.getInt(1));
					doc.setDateOfEnrollment(rs.getString(2));
					doc.setAdharNo(rs.getLong(3));
					doc.setPancard(rs.getString(4));
					listOfRec.add(doc);
				}
			} catch (Exception e) {
				System.out.println(e.toString());
			}
			return listOfRec;
		}
	public Document getDocumentsByApplicationNo(int appNo) {
		try {
			con = dataSource.getConnection();				
			pstmt = con.prepareStatement("select * from documents where APPLICATION_NO=?");
			pstmt.setInt(1,appNo);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				//System.out.println(rs.getInt(1)+"integer");
				Document doc = new Document();
				doc.setApplicationNo(rs.getInt(1));
			    doc.setDateOfEnrollment(rs.getString(2));
				doc.setAdharNo(rs.getLong(3));
				doc.setPancard(rs.getString(4));
				//System.out.println(doc.getApplicationNo());
				return doc;
			}
		} catch (Exception e) {
		System.out.println(e.toString());
		}
		return null;
	}
	public int storeDocuments(Document doc) {
		try {//System.out.println(doc.getApplicationNo());
			//LocalDate da=LocalDate.now();
			//DateTimeFormatter df=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
			//String date=da.format(df);
			System.out.println(doc);
			con = dataSource.getConnection();
			pstmt = con.prepareStatement("insert into documents values(?,?,?,?)");
			pstmt.setFloat(1,doc.getApplicationNo());
			pstmt.setString(2,doc.getDateOfEnrollment());
			//pstmt.setString(2,date);
			pstmt.setLong(3,doc.getAdharNo());
			pstmt.setString(4, doc.getPancard());
			if( pstmt.executeUpdate()>0) {
				//con.commit();
				return 1;
			}else {
				return 0;
			}
			
		} catch (Exception e) {
			System.out.println(e);
			return 0;
		}
	}
	public int deleteDocumentsDetails(int applicationno ) {
		try {
			con = dataSource.getConnection();				
			pstmt = con.prepareStatement("delete from documents where APPLICATION_NO=?");
			pstmt.setFloat(1,applicationno);
			return pstmt.executeUpdate();
		} catch (Exception e) {
			return 0;
		}
	}
}
