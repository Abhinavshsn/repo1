package finance.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import finance.bean.LoanApplication;
import finance.dao.LoanApplicationDao;

@Service
public class LoanApplicationService {

	@Autowired
	LoanApplicationDao ld;
	
	public List<LoanApplication> getAllApplication() {
		return ld.getAllLappDetails();
	}
	
	public LoanApplication getApplicationById(int id) {
		return ld.getLapById(id);
	}
	
	public String storeApplicationDetails(LoanApplication la) {
		return ld.storeLapRecord(la);
	}
	
	/*public String updateApplicationDetails(LoanApplication la) {
		if(lad.updateLapDetails(la)>0) {
			return "Record updated successfully";
		}else {
			return "Record didn't update";
		}
	}*/
	
	public String deleteApplicationById(int App) {
		return ld.deleteLapById(App);
			
	}
}
