package finance.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import finance.bean.Customer;
import finance.dao.CustomerDao;
import finance.bean.LoanRec;
import finance.dao.LoanRecDao;
import finance.service.LoanRecService;

@Service																// @Service layer annotation 
public class LoanRecService {

	@Autowired
	LoanRecDao loanrecDao;
	
	public List<LoanRec> getAllLoanRec() {
		return loanrecDao.getAllLoanRec();
	}
	
	public LoanRec getLoanRecById(long loan_id) {
		return loanrecDao.getLoanRecById(loan_id);
	}
	
	public String storeLoanRecord(LoanRec lr) {
		if(loanrecDao.storeLoanRecord(lr)>0) {
			return "Record stored successfully";
		}else {
			return "Record didn't store";
		}
	}
	
	public String updateLoanRecord(LoanRec lr) {
		if(loanrecDao.updateLoanRecord(lr)>0) {
			return "Record updated successfully";
		}else {
			return "Record didn't update";
		}
	}
	
	public String deleteLoanRecById(long loan_id) {
		if(loanrecDao.deleteLoanRecById(loan_id)>0) {
			return "Record deleted successfully";
		}else {
			return "Record didn't delete";
		}
	}
	
	
	
}

