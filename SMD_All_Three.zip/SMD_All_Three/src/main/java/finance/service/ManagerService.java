package finance.service;

import java.util.List;
import java.util.ArrayList;



import finance.dao.LoanApplicationDao;
import finance.dao.LoanRecDao;
import finance.dao.DocumentsDao;
import finance.dao.CustomerDao;
import finance.dao.ManagerDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import finance.bean.Customer;
import finance.bean.Document;
import finance.bean.LoanApplication;
import finance.bean.LoanRec;
import finance.bean.Manager;


@Service
public class ManagerService {
	@Autowired
	ManagerDao managerDao;

	public String getAllDetails() {
		
		
		
		if(managerDao.getAllDetails()>0) {
			return "Record updated successfully";
		}else {
			return "Record didn't update";
		}
	}
	
	public List<Customer> getManagerById(String ls) {
		return managerDao.getManagerById(ls);
	}
	
	public List<LoanApplication> getAllRecByStatus() {
		return managerDao.getAllCustomerDetails();
	}
	
}
