package finance.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import finance.bean.Customer;
import finance.dao.CustomerDao;
import finance.service.CustomerService;

@Service																// @Service layer annotation 
public class CustomerService {

	@Autowired
	CustomerDao customerDao;
	

	public List<Customer> getAllCustomer() {
		return customerDao.getAllCustomerDetails();
	}
	
	public Customer getCustomerById(long cust_id) {
		return customerDao.getCustomerById(cust_id);
	}
	
	public String storeCustomerDetails(Customer cust) {
		if(customerDao.storeCustomerRecord(cust)>0) {
			return "Record stored successfully";
		}else {
			return "Record didn't store";
		}
	}
	
	public String updateCustomerContact(Customer cust) {
		if(customerDao.updateCustomerContact(cust)>0) {
			return "Record updated successfully";
		}else {
			return "Record didn't update";
		}
	}
	
	public String updateCustomerMailId(Customer cust) {
		if(customerDao.updateCustomerMailId(cust)>0) {
			return "Record updated successfully";
		}else {
			return "Record didn't update";
		}
	}
	
	public String updateCustomerPassword(Customer cust) {
		if(customerDao.updateCustomerPassword(cust)>0) {
			return "Record updated successfully";
		}else {
			return "Record didn't update";
		}
	}
	
	public Boolean checkDetails(Customer cust) {
		String passwordDb=customerDao.checkDetails(cust);
		if(passwordDb.length()>0) {
		
			return passwordDb.equals(cust.getPassword());
			
		}else {
			return false;
		}
	}
	
	public String deleteCustomerById(long cust_id) {
		if(customerDao.deleteCustomerById(cust_id)>0) {
			return "Record deleted successfully";
		}else {
			return "Record didn't delete";
		}
	}
	
	
	
	
}
