package finance.service;

import java.util.List;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import finance.dao.DocumentsDao;
import finance.bean.Document;

@Service
public class DocumentsService {
@Autowired
DocumentsDao documentsdao;
public List<Document> getAllDocuments() {
	return documentsdao.getDocumentsDetails();
}
public Document getDocumentsByApplicationNo(int no) {
	return documentsdao.getDocumentsByApplicationNo(no);
}
public String storeDocuments(Document doc) {
	System.out.println("in service"+doc);
	if (documentsdao.storeDocuments(doc)>0) {
		return "record stored succesfully";
	}else {
		return "Record didn't store";
	}
}
public String deleteDocumentsDetails(int id) {
if(documentsdao.deleteDocumentsDetails(id)>0) {
	return "Record deleted succesfully";
}else {
	return "Record didn't delete";
}
}
}
