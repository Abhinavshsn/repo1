package finance.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import finance.bean.Clerk;
import finance.bean.Customer;
import finance.bean.LoanApplication;
import finance.dao.ClerkDao;

@Service
public class ClerkService {
	@Autowired
	ClerkDao cd;
	
	public List<Clerk> getAllLoanDetails() {
		return cd.getAllCustomerDetails();
	}

	public List<LoanApplication> getAllApp() {
		return cd.getAllApplications();
	}
	
	public String storeApp(LoanApplication la) {
		return cd.storeLapRecord(la);
	}
	
	public List<Customer> getAllCust() {
		return cd.getAllCustomer();
	}
	
	public String deleteApplicationById(int App) {
		return cd.deleteLapById(App);
			
	}
	
	public String updateCustomerDetails(Customer cust) {
		if(cd.updateCustomerDetails(cust)>0) {
			return "Record updated successfully";
		}else {
			return "Record didn't update";
		}
	}
	
	public String deleteCustomerById(long cust_id) {
		if(cd.deleteCustomerById(cust_id)>0) {
			return "Record deleted successfully";
		}else {
			return "Record didn't delete";
		}
	}
	
	
	
	
}
